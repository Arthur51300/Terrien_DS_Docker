export const environment = {
  production: true,
  backendUrl: 'http://1.2.3.4:8448'
};
